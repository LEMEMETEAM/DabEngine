QUAKE MODELS DON'T HAVE BONES. 
They're stored as vertex animation. As a result they also don't have a reference pose (most of the time).

But I felt it could still be helpful to upload this as a resource, so the fbx includes all the vertex animation.

I've also included a static obj in order to comply with upload policy.